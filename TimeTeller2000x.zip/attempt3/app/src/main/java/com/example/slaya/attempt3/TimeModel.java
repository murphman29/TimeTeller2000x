package com.example.slaya.attempt3;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author slaya
 */
class TimeModel {
    private static TimeModel single_instance = null;
    private static ArrayDeque <Action> doneActions = new ArrayDeque();
    private static ArrayDeque <Action> undoneActions = new ArrayDeque();
    private static Date theDate = new Date();
    private static Controller alpha;
    static SimpleDateFormat ft = new SimpleDateFormat ("MM/dd/yyyy hh:mm:ss");

    private TimeModel(){
        theDate.setTime(System.currentTimeMillis());
    }
    public static SimpleDateFormat getFormat(){
        return ft;
    }

    public static TimeModel getInstance(){
        if(single_instance == null){
            single_instance = new TimeModel();
        }
        return single_instance;
    }

    public static Date getTime(){
        return theDate;
    }

    public static void execute(TimeChange theChange){
        try{
            theChange.doIt();
            doneActions.push(theChange);
        }catch(Exception e){
            System.out.println("Oopsies!");
        }
    }
    public static void registerController(Controller c){
        alpha = c;
    }

    public static void setTime(Date newDate){
        theDate = newDate;
        updateController();
    }

    private static void updateController(){
        alpha.update();
    }

    public static boolean undoIt(){
        if(doneActions.isEmpty()){
            return false;
        }else{
            Action A = doneActions.pop();
            A.UndoIt();
            undoneActions.push(A);
            return true;
        }
    }

    public static boolean redoIt(){
        if(undoneActions.isEmpty()){
            return false;
        }else{
            Action A = undoneActions.pop();
            A.doIt();
            doneActions.push(A);
            return true;
        }
    }
}

interface Action{
    public void doIt();
    public void UndoIt();
}


class TimeChange implements Action {
    private Date newDate;
    private Date oldDate;

    public TimeChange(Date newDate) {
        this.newDate = newDate;
    }

    @Override
    public void doIt() {
        oldDate = TimeModel.getTime();
        TimeModel.setTime(newDate);
    }

    @Override
    public void UndoIt() {
        newDate = TimeModel.getTime();
        TimeModel.setTime(oldDate);
    }
}
