package com.example.slaya.attempt3;

import android.content.Context;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;

interface ClockView{
    void update(Date theDate,SimpleDateFormat ft);
    void registerView();
}




