package com.example.slaya.attempt3;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import android.view.View;
import android.content.Context;

/**
 *
 * @author slaya
 */

    public class Controller {

        TimeModel theModel;
        ArrayList<ClockView> theView;
        Thread t;

        public Controller() {
            this.theModel = theModel; //Link the controller to the model
            TimeModel.registerController(this); //Link the model to the controller
            theView = new ArrayList<ClockView>();
        }

        public void registerView(ClockView v) {
            theView.add(v);
        }

        public void updateTime(Date date){
            TimeModel.setTime(date);
        }

        public void changeTime(String t) {
            try {
                SimpleDateFormat ft = TimeModel.getFormat();
                Date d = ft.parse(t);
                TimeChange tc = new TimeChange(d);
                TimeModel.execute(tc);
            } catch (Exception e) {
                System.out.println("Invalid time!");
            }
        }

        public void doIt(){
            TimeModel.redoIt();
        }

        public void undoIt(){
            TimeModel.undoIt();
        }
        public void update(){
            Date updatedTime = TimeModel.getTime();
            SimpleDateFormat ft = TimeModel.getFormat();
            for(int i = 0; i!= theView.size(); i++){
                theView.get(i).update(updatedTime, ft);
            }
        }

    }