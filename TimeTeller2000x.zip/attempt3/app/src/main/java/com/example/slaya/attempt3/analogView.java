package com.example.slaya.attempt3;

import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class analogView implements ClockView {
    Controller c; // Comes from super class
    TextView tv;

    public analogView(Controller theController, TextView tv){
        c = theController;
        this.tv = tv;
        registerView();
    }
    @Override
    public void registerView(){
        c.registerView(this);
    }

    @Override
    public void update(Date theDate, SimpleDateFormat ft){
        SimpleDateFormat time = new SimpleDateFormat("MM.dd.yyyy");
        SimpleDateFormat hour = new SimpleDateFormat("hh");
        SimpleDateFormat minute = new SimpleDateFormat("mm");
        SimpleDateFormat second = new SimpleDateFormat("ss");
        if(tv.getText().length() > 350){
            tv.setText("");
        }
        tv.setText(tv.getText() + (time.format(theDate)) + " Hour:" + hour.format(theDate) + " Minute: " +  minute.format(theDate) + " Second: " +  second.format(theDate)+ "\n");
    }
}
