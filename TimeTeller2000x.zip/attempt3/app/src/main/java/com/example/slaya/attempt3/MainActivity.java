package com.example.slaya.attempt3;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {
static Controller c;
static TextView resultView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TimeModel.getInstance();
        makeThread();
        c = new Controller();
        resultView = findViewById(R.id.resultView);
        final PopupWindow popup = new PopupWindow();


        //Link fields and buttons to java program
        //Date inputs
       final ArrayList<EditText> dateFields = new ArrayList<EditText>();
        dateFields.add((EditText) findViewById(R.id.monthBox));
        dateFields.add((EditText) findViewById(R.id.dayBox));
        dateFields.add((EditText) findViewById(R.id.yearBox));
        dateFields.add((EditText) findViewById(R.id.hourBox));
        dateFields.add((EditText) findViewById(R.id.minuteBox));
        dateFields.add((EditText) findViewById(R.id.secondBox));


        //Buttons
        Button changeTime = (Button) findViewById(R.id.changeTimeButton);

        Button undo = (Button) findViewById(R.id.undo);
        Button redo = (Button) findViewById(R.id.redo);

        Button newDigital = (Button) findViewById(R.id.clockOne);
        Button newAnalog = (Button) findViewById(R.id.clockTwo);

        //Set Button Functionality
        changeTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String theDate = "";
               for(int i = 0; i != 6; i++){
                   theDate += dateFields.get(i).getText();
                   if(i == 0 | i == 1){
                       theDate+="/";
                   }
                   if(i == 2){
                       theDate+=" ";
                   }
                   if(i == 3 | i == 4){
                       theDate+=":";
                   }
               }
               c.changeTime(theDate);//Send the update request to the controller
            }
        });

        newDigital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              digitalView view = new digitalView(c, resultView);
            }
        });


        newAnalog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                analogView view = new analogView(c, resultView);
            }
        });

        undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.undoIt();
            }
        });
        redo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.doIt();
            }
        });




    }
    private static void makeThread(){
        Timer timer = new Timer();
        timer.schedule( new TimerTask()
        {
            @Override
            public void run() {
                try{
                    Date newTime = TimeModel.getTime();
                    newTime.setTime(newTime.getTime() + 1000);
                    c.updateTime(newTime);
                }catch(Exception e){

                }}
        }, 0, (1000*1));
    }

}
