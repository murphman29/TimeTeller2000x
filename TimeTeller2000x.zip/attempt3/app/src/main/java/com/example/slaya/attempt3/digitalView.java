package com.example.slaya.attempt3;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

class digitalView implements ClockView {    

    //private RelativeLayout slave;

    Controller c; // Comes from super class
    TextView tv;

    public digitalView(Controller theController, TextView tv){
        c = theController;
        this.tv = tv;
        registerView();
    }
    @Override
    public void registerView(){
        c.registerView(this);
    }

    @Override
    public void update(Date theDate, SimpleDateFormat ft){
        SimpleDateFormat time = new SimpleDateFormat("MM.dd.yyyy hh:mm:ss");
        if(tv.getText().length() > 300){
            tv.setText("");
        }
        tv.setText(tv.getText() + (time.format(theDate)) + "\n");
    }
}